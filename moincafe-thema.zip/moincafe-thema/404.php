<?php get_header(); ?>
<main>
    <h2>ページが見つかりません</h2>
    <p>申し訳ありません。指定されたページは存在しません。</p>
</main>
<?php get_footer(); ?>
